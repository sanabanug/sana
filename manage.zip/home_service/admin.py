from django.contrib import admin

from .models import *

# Register your models here.
admin.site.register(Status)
admin.site.register(Contact)
admin.site.register(ID_Card)
admin.site.register(Order)
admin.site.register(Service_Category)
admin.site.register(Service)
admin.site.register(Customer)
admin.site.register(Service_Man)
admin.site.register(Total_Man)

